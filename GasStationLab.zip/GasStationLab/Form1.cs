namespace GasStationLab
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox6.Enabled = false;
            textBox8.Enabled = false;
            textBox10.Enabled = false;
            textBox5.Enabled = false;
            textBox7.Enabled = false;
            textBox9.Enabled = false;
            textBox11.Enabled = false;
        }



        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Enabled == true)
            {
                textBox1.Text = "51";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Enabled == true)
            {
                textBox1.Text = "54";
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Enabled == true)
            {
                textBox2.Enabled = true;
                textBox3.Enabled = false;
            }
        }
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Enabled == true)
            {
                textBox2.Enabled = false;
                textBox3.Enabled = true;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                int price = int.Parse(textBox1.Text);
                int l = int.Parse(textBox2.Text);

                int sum = price * l;

                label4.Text = sum.ToString();
            }
            else if (radioButton4.Checked)
            {
                int price = int.Parse(textBox1.Text);
                int l = int.Parse(textBox3.Text);

                int sum = l / price;
                textBox2.Text = sum.ToString();
                label4.Text = textBox3.Text;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox5.Enabled = true;
            }
            else
            {
                textBox5.Enabled = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                textBox7.Enabled = true;
            }
            else
            {
                textBox7.Enabled = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                textBox9.Enabled = true;
            }
            else
            {
                textBox9.Enabled = false;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                textBox11.Enabled = true;
            }
            else
            {
                textBox11.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int alsum = 0;
            if (checkBox1.Checked && textBox5.Text != "")
            {
                alsum += int.Parse(textBox4.Text) * int.Parse(textBox5.Text);
            }
            if (checkBox2.Checked && textBox7.Text != "")
            {
                alsum += int.Parse(textBox6.Text) * int.Parse(textBox7.Text);
            }
            if (checkBox3.Checked && textBox9.Text != "")
            {
                alsum += int.Parse(textBox8.Text) * int.Parse(textBox9.Text);
            }
            if (checkBox4.Checked && textBox11.Text != "")
            {
                alsum += int.Parse(textBox10.Text) * int.Parse(textBox11.Text);
            }

            label8.Text = alsum.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = int.Parse(label8.Text) + int.Parse(label4.Text);
            label6.Text = sum.ToString();
            MessageBox.Show("������, �������� ��!");
        }
    }
}