﻿namespace GasStationLab
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            groupBox6 = new GroupBox();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            label13 = new Label();
            label12 = new Label();
            groupBox4 = new GroupBox();
            button2 = new Button();
            label5 = new Label();
            label4 = new Label();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            label3 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            groupBox2 = new GroupBox();
            textBox11 = new TextBox();
            textBox10 = new TextBox();
            textBox9 = new TextBox();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            label11 = new Label();
            label10 = new Label();
            checkBox4 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            groupBox5 = new GroupBox();
            button3 = new Button();
            label9 = new Label();
            label8 = new Label();
            groupBox3 = new GroupBox();
            label7 = new Label();
            label6 = new Label();
            button1 = new Button();
            groupBox1.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(groupBox6);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(groupBox4);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(radioButton2);
            groupBox1.Controls.Add(radioButton1);
            groupBox1.ForeColor = SystemColors.ControlText;
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(375, 306);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Автозаправка";
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(radioButton3);
            groupBox6.Controls.Add(radioButton4);
            groupBox6.Location = new Point(32, 140);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(148, 79);
            groupBox6.TabIndex = 13;
            groupBox6.TabStop = false;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(20, 22);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(77, 19);
            radioButton3.TabIndex = 6;
            radioButton3.TabStop = true;
            radioButton3.Text = "Кількість ";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new Point(20, 46);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(54, 19);
            radioButton4.TabIndex = 7;
            radioButton4.TabStop = true;
            radioButton4.Text = "Сума";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioButton4_CheckedChanged;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(331, 194);
            label13.Name = "label13";
            label13.Size = new Size(29, 15);
            label13.TabIndex = 12;
            label13.Text = "грн.";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(331, 166);
            label12.Name = "label12";
            label12.Size = new Size(17, 15);
            label12.TabIndex = 11;
            label12.Text = "л.";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(button2);
            groupBox4.Controls.Add(label5);
            groupBox4.Controls.Add(label4);
            groupBox4.Location = new Point(6, 225);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(363, 75);
            groupBox4.TabIndex = 10;
            groupBox4.TabStop = false;
            groupBox4.Text = "До оплати:";
            // 
            // button2
            // 
            button2.Location = new Point(6, 25);
            button2.Name = "button2";
            button2.Size = new Size(103, 33);
            button2.TabIndex = 2;
            button2.Text = "Порахувати";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(325, 43);
            label5.Name = "label5";
            label5.Size = new Size(29, 15);
            label5.TabIndex = 1;
            label5.Text = "грн.";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(257, 35);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 0;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(225, 185);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 9;
            textBox3.Text = "0";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(225, 158);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 8;
            textBox2.Text = "0";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(272, 118);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 5;
            label3.Text = "грн.";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(166, 110);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(42, 110);
            label2.Name = "label2";
            label2.Size = new Size(32, 15);
            label2.TabIndex = 3;
            label2.Text = "Ціна";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(42, 46);
            label1.Name = "label1";
            label1.Size = new Size(46, 15);
            label1.TabIndex = 2;
            label1.Text = "Бензин";
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(166, 68);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(37, 19);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "95";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(166, 43);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(37, 19);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "92";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBox11);
            groupBox2.Controls.Add(textBox10);
            groupBox2.Controls.Add(textBox9);
            groupBox2.Controls.Add(textBox8);
            groupBox2.Controls.Add(textBox7);
            groupBox2.Controls.Add(textBox6);
            groupBox2.Controls.Add(textBox5);
            groupBox2.Controls.Add(textBox4);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(checkBox4);
            groupBox2.Controls.Add(checkBox3);
            groupBox2.Controls.Add(checkBox2);
            groupBox2.Controls.Add(checkBox1);
            groupBox2.Controls.Add(groupBox5);
            groupBox2.Location = new Point(393, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(395, 306);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Міні-Кафе";
            // 
            // textBox11
            // 
            textBox11.Location = new Point(280, 186);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(100, 23);
            textBox11.TabIndex = 14;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(163, 186);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(100, 23);
            textBox10.TabIndex = 13;
            textBox10.Text = "18";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(280, 136);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(100, 23);
            textBox9.TabIndex = 12;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(163, 136);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(100, 23);
            textBox8.TabIndex = 11;
            textBox8.Text = "20";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(280, 88);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(100, 23);
            textBox7.TabIndex = 10;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(163, 88);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(100, 23);
            textBox6.TabIndex = 9;
            textBox6.Text = "35";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(280, 43);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(100, 23);
            textBox5.TabIndex = 8;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(163, 43);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 7;
            textBox4.Text = "25";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(305, 19);
            label11.Name = "label11";
            label11.Size = new Size(56, 15);
            label11.TabIndex = 6;
            label11.Text = "Кількість";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(191, 19);
            label10.Name = "label10";
            label10.Size = new Size(32, 15);
            label10.TabIndex = 5;
            label10.Text = "Ціна";
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(6, 190);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(83, 19);
            checkBox4.TabIndex = 4;
            checkBox4.Text = "Кока-кола";
            checkBox4.UseVisualStyleBackColor = true;
            checkBox4.CheckedChanged += checkBox4_CheckedChanged;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(6, 140);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(102, 19);
            checkBox3.TabIndex = 3;
            checkBox3.Text = "Картопля-фрі";
            checkBox3.UseVisualStyleBackColor = true;
            checkBox3.CheckedChanged += checkBox3_CheckedChanged;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(6, 92);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(85, 19);
            checkBox2.TabIndex = 2;
            checkBox2.Text = "Гамбургер";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(6, 47);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(68, 19);
            checkBox1.TabIndex = 1;
            checkBox1.Text = "Хот-дог";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(button3);
            groupBox5.Controls.Add(label9);
            groupBox5.Controls.Add(label8);
            groupBox5.Location = new Point(6, 225);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(383, 75);
            groupBox5.TabIndex = 0;
            groupBox5.TabStop = false;
            groupBox5.Text = "До оплати:";
            // 
            // button3
            // 
            button3.Location = new Point(6, 26);
            button3.Name = "button3";
            button3.Size = new Size(103, 32);
            button3.TabIndex = 2;
            button3.Text = "Порахувати";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(345, 43);
            label9.Name = "label9";
            label9.Size = new Size(29, 15);
            label9.TabIndex = 1;
            label9.Text = "грн.";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(266, 33);
            label8.Name = "label8";
            label8.Size = new Size(0, 15);
            label8.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(label6);
            groupBox3.Controls.Add(button1);
            groupBox3.Location = new Point(12, 324);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(776, 114);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Всього до оплати";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(732, 84);
            label7.Name = "label7";
            label7.Size = new Size(29, 15);
            label7.TabIndex = 2;
            label7.Text = "грн.";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(640, 58);
            label6.Name = "label6";
            label6.Size = new Size(0, 15);
            label6.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(32, 22);
            button1.Name = "button1";
            button1.Size = new Size(171, 86);
            button1.TabIndex = 0;
            button1.Text = "Порахувати";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox3;
        private TextBox textBox2;
        private RadioButton radioButton4;
        private RadioButton radioButton3;
        private Label label3;
        private TextBox textBox1;
        private Label label2;
        private Label label1;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private Label label5;
        private Label label4;
        private TextBox textBox11;
        private TextBox textBox10;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private Label label11;
        private Label label10;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private GroupBox groupBox5;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Button button1;
        private Label label13;
        private Label label12;
        private GroupBox groupBox6;
        private Button button2;
        private Button button3;
    }
}